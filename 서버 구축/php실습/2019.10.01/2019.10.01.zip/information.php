﻿<html>
	<head>
		<title>
			form 태그 공부
		</title>
	</head>
	<body>
	<?
	echo $_POST["name_text"];
	echo "<br>";
	echo $_POST["is_gender"];
	echo "<br>";
	echo $_POST["address_text"];
	?>
	</body>
</html>